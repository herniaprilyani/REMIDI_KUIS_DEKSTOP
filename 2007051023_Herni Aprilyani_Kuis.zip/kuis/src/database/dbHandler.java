/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cpu;

public class dbHandler {
    public final Connection conn;

    public dbHandler(String driver) {
        this.conn = dbHelper.getConnection(driver);
    }
    public void addCPU(Cpu datacpu){
        String insertDatacpu = "INSERT INTO `datacpu`(`id`, `merek`,`harga`,`warna`,`tanggal`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertDatacpu);
            stmtInsert.setString(1, datacpu.getId());
            stmtInsert.setString(2, datacpu.getMerek());
            stmtInsert.setString(3, datacpu.getWarna());
            stmtInsert.setString(4, datacpu.getHarga());
            stmtInsert.setString(5, datacpu.getTanggal());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(dbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}